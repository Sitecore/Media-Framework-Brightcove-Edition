Sitecore Media Framework Brightcove Edition 9.0
-------------------------------------------------------------
Date: 12-Dec-2017
-------------------------------------------------------------
Prerequisites:
-  Sitecore 9.0 rev. 171002
-------------------------------------------------------------
After installation, update the Sitecore.MediaFramework.Services.Brightcove.Extended.config.disabled file with the correct values, then remove the .disabled extension.
-------------------------------------------------------------
Sitecore® is a registered trademark. All other brand and
product names are the property of their respective holders. All rights reserved.
